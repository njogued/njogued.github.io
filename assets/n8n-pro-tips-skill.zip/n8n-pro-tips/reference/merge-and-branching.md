# Merge and Branching

Reconverging branches, error routing, and empty-result guards.

---

## Merge Node Modes: Append vs Combine

> **Severity: High.** Wrong merge mode causes either missing items (branch never fires) or duplicates (fallback runs when it shouldn’t).
> 

**The Problem:** When an IF or Switch node splits a flow into multiple branches and you want to reconverge them downstream, the Merge node’s mode determines whether items actually pass through. The right choice depends on whether your branches are **mutually exclusive** (only one fires per item) or **both required** (both must produce data for the merge to make sense).

---

### The Most Common Case: Either/Or Convergence (Append)

The typical pattern: an IF node splits the flow based on some condition, each branch does different processing, and a Merge node downstream collects whichever branch ran so the rest of the workflow can continue.

```
[IF: has files?]
  TRUE  → [Process with media analysis] ──┐
  FALSE → [Process text only] ────────────┴→ [Merge: Append] → [Continue...]
```

Because the IF guarantees only ONE branch fires per item, you want the Merge node to pass through whichever branch produced output. That’s **Append mode**: it needs only one input to fire and forwards everything that arrived.

**Use Append when:**

- Branches are mutually exclusive (IF / Switch)
- Each branch produces the same shape of output (or compatible shapes)
- You want “whichever path ran, pass it along”

**Real-world example**: Slack message capture with conditional media analysis:

```
[Check If Message Has Files?]
                 │
     ┌───────────┴──────────┐
     │                      │
    Yes                     No
     │                      │
     ▼                      ▼
[Analyze Media]    [Build Message Record]
     │              (Text Only)
     ▼                      │
[Build Message Record]      │
(Text + Media Description)  │ 
     │                      │ 
     └──────────┬───────────┘
                ▼
   [Merge Message Records]
                ▼
             [Upsert]
```

Both Set nodes produce the same column shape, so the downstream upsert doesn’t care which branch ran. Append is correct.

---

### The Exception: Both Inputs Required (Combine)

**Combine mode (all possible combinations)** needs **both inputs** to fire. It creates the cartesian product of its inputs. If one input has no data, the Merge produces nothing.

This is the right mode when:

- You’re recombining data that was deliberately split (e.g. an error output and the original binary)
- The downstream node needs fields from BOTH branches to function
- You want the merge to act as a gate: only proceed if both sides produced data

**Real-world example**: OpenRouter vision call with Gemini fallback (combines patterns from *OpenRouter for Vision: Multi-Model Fallback With One HTTP Call*, in `binary-and-http.md`):

```
Slack Image
    ↓
Download Image
    ↓
Convert to Base64/Data URL
    ↓
 ┌─────────────────────┐
 │                     │
 ↓                     ↓
OpenRouter Vision   Gemini Vision
 ↓                     ↓
Description A      Description B
 │                     │
 └─────── Merge ───────┘
          ↓
Combined media description
          ↓
Attach to message
          ↓
Save to Supabase
```

Why Combine on the gate:

- On success, the error output has nothing → Combine doesn’t fire → Gemini fallback skipped ✅
- On failure, both inputs have data (binary + error) → Combine fires → Gemini runs with the binary it needs ✅
- If you used Append here, the binary alone would fire the merge even on success, and Gemini would run unnecessarily, producing duplicate results.

The final Merge in this flow is Append, because the Success and Fallback paths are mutually exclusive: only one ever produces a description per item.

---

### Want to See It in Action?

Paste this into a fresh n8n canvas to play with both patterns end-to-end. Add your own Slack and OpenRouter credentials to the relevant nodes after import.

- Click to expand: Reference workflow JSON
    
    ```json
    {
      "nodes": [
        {
          "parameters": {
            "method": "POST",
            "url": "https://openrouter.ai/api/v1/chat/completions",
            "authentication": "predefinedCredentialType",
            "nodeCredentialType": "openRouterApi",
            "sendHeaders": true,
            "headerParameters": {
              "parameters": [
                {
                  "name": "Content-Type",
                  "value": "application/json"
                }
              ]
            },
            "sendBody": true,
            "specifyBody": "json",
            "jsonBody": "={\n\"models\": [\"qwen/qwen3.5-plus-02-15\",\"google/gemini-2.0-flash-lite-001\",\"google/gemini-2.5-flash\"],\n\"messages\": [\n    {\n\"role\":\"user\",\n\"content\": [\n        {\n\"type\":\"text\",\n\"text\":\"Analyze this image:\"\n        },\n        {\n\"type\":\"image_url\",\n\"image_url\": {\n\"url\":\"{{ $json.dataUrl }}\"\n          }\n        }\n      ]\n    }\n  ],\n\"stream\": false\n}",
            "options": {}
          },
          "type": "n8n-nodes-base.httpRequest",
          "typeVersion": 4.4,
          "position": [
            2672,
            2160
          ],
          "id": "d9fceb18-8960-4a39-a4dd-ef4f650d0fca",
          "name": "Get Image Description - OpenRouter",
          "onError": "continueErrorOutput"
        },
        {
          "parameters": {
            "mode": "combine",
            "combineBy": "combineAll",
            "options": {}
          },
          "type": "n8n-nodes-base.merge",
          "typeVersion": 3.2,
          "position": [
            2960,
            2320
          ],
          "id": "a9c96f20-b911-44f4-b8d5-147c639ef540",
          "name": "Merge [COMBINE]"
        },
        {
          "parameters": {
            "resource": "image",
            "operation": "analyze",
            "modelId": {
              "__rl": true,
              "value": "models/gemini-2.5-flash",
              "mode": "list",
              "cachedResultName": "models/gemini-2.5-flash"
            },
            "text": "=Analyze this image:",
            "inputType": "binary",
            "options": {}
          },
          "type": "@n8n/n8n-nodes-langchain.googleGemini",
          "typeVersion": 1.1,
          "position": [
            3200,
            2320
          ],
          "id": "fc2c1e25-525d-4f75-9da9-76da4aad8270",
          "name": "Gemini Analysis",
          "onError": "continueRegularOutput"
        },
        {
          "parameters": {
            "assignments": {
              "assignments": [
                {
                  "id": "626657af-65f1-4451-be42-8b046d1ba62e",
                  "name": "description",
                  "value": "=MEDIA ANALYSIS: {{ $json?.choices[0]?.message?.content }}",
                  "type": "string"
                }
              ]
            },
            "options": {}
          },
          "type": "n8n-nodes-base.set",
          "typeVersion": 3.4,
          "position": [
            3200,
            2144
          ],
          "id": "aa8b314e-4ee7-4183-b877-a3b074c57aa1",
          "name": "Set Description",
          "executeOnce": false
        },
        {
          "parameters": {
            "assignments": {
              "assignments": [
                {
                  "id": "626657af-65f1-4451-be42-8b046d1ba62e",
                  "name": "description",
                  "value": "={{ $json?.content?.parts[0]?.text ? `MEDIA ANALYSIS:\\n\\n${$json.content.parts[0].text}` :\"\" }}",
                  "type": "string"
                }
              ]
            },
            "options": {}
          },
          "type": "n8n-nodes-base.set",
          "typeVersion": 3.4,
          "position": [
            3488,
            2320
          ],
          "id": "48748326-af9c-41b2-8284-3a776943bf61",
          "name": "Set Gemini Analysis Description",
          "executeOnce": false
        },
        {
          "parameters": {},
          "type": "n8n-nodes-base.merge",
          "typeVersion": 3.2,
          "position": [
            3760,
            2240
          ],
          "id": "d32747de-1ae7-4c3d-baaf-3f9eeac095ff",
          "name": "Merge [APPEND]"
        },
        {
          "parameters": {
            "url": "={{ $json.url_private_download }}",
            "authentication": "predefinedCredentialType",
            "nodeCredentialType": "slackApi",
            "options": {
              "response": {
                "response": {
                  "responseFormat": "file"
                }
              }
            }
          },
          "type": "n8n-nodes-base.httpRequest",
          "typeVersion": 4.4,
          "position": [
            2112,
            2176
          ],
          "id": "206ae316-a450-4f0a-8173-969b7dbf3fc3",
          "name": "Download Image (Returns Binary)",
          "alwaysOutputData": false
        },
        {
          "parameters": {
            "mode": "runOnceForEachItem",
            "jsCode": "// n8n-recommended approach for getting binary data\nconst buffer = await this.helpers.getBinaryDataBuffer(0, 'data');\nconst base64String = buffer.toString('base64');\n\n// Grab metadata (still on the object)\nconst mimeMeta = $input.item.binary.data;\n\n// Derive MIME type from filename extension\nconst ext = (mimeMeta.fileName || '').split('.').pop().toLowerCase();\nconst mimeMap = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp' };\nconst mimeTypeFile = mimeMap[ext] || mimeMeta.mimeType || 'image/png';\n\nreturn {\n  json: {\n    base64: base64String,\n    fileName: mimeMeta.fileName,\n    mimeType: mimeMeta.mimeType,\n    dataUrl: `data:${mimeTypeFile};base64,${base64String}`\n  }\n};"
          },
          "type": "n8n-nodes-base.code",
          "typeVersion": 2,
          "position": [
            2416,
            2176
          ],
          "id": "34370473-12e3-43cc-9d82-12ea65b93b30",
          "name": "Generate base64 String for File",
          "onError": "continueErrorOutput"
        }
      ],
      "connections": {
        "Get Image Description - OpenRouter": {
          "main": [
            [
              {
                "node": "Set Description",
                "type": "main",
                "index": 0
              }
            ],
            [
              {
                "node": "Merge [COMBINE]",
                "type": "main",
                "index": 0
              }
            ]
          ]
        },
        "Merge [COMBINE]": {
          "main": [
            [
              {
                "node": "Gemini Analysis",
                "type": "main",
                "index": 0
              }
            ]
          ]
        },
        "Gemini Analysis": {
          "main": [
            [
              {
                "node": "Set Gemini Analysis Description",
                "type": "main",
                "index": 0
              }
            ]
          ]
        },
        "Set Description": {
          "main": [
            [
              {
                "node": "Merge [APPEND]",
                "type": "main",
                "index": 0
              }
            ]
          ]
        },
        "Set Gemini Analysis Description": {
          "main": [
            [
              {
                "node": "Merge [APPEND]",
                "type": "main",
                "index": 1
              }
            ]
          ]
        },
        "Download Image (Returns Binary)": {
          "main": [
            [
              {
                "node": "Generate base64 String for File",
                "type": "main",
                "index": 0
              },
              {
                "node": "Merge [COMBINE]",
                "type": "main",
                "index": 1
              }
            ]
          ]
        },
        "Generate base64 String for File": {
          "main": [
            [
              {
                "node": "Get Image Description - OpenRouter",
                "type": "main",
                "index": 0
              }
            ],
            [
              {
                "node": "Merge [COMBINE]",
                "type": "main",
                "index": 0
              }
            ]
          ]
        }
      },
      "pinData": {}
    }
    ```
    

---

### Rule of Thumb

| Branches are… | Use | Why |
| --- | --- | --- |
| Mutually exclusive (IF) | **Append** | Only one fires; merge just forwards whichever ran |
| Independent, both needed | **Combine** | Both must produce data for downstream to make sense |
| Error gates (fallback) | **Combine** | Prevents fallback from firing when primary succeeded |
| Final output collection | **Append** | Collect results from multiple branches regardless |

---

### Quick Debugging Check

If a Merge node isn’t behaving as expected:

- **Missing items?** You may be using Combine where Append is needed. One of your inputs is empty by design (e.g. an IF branch that didn’t fire), so Combine produces nothing.
- **Duplicate items?** You may be using Append where Combine is needed. A branch you intended to skip is firing because Append only needs one input.

---

## Error Handling: Continue on Fail Options

When a node fails in n8n, the default behavior is to stop the entire workflow. But you have two “Continue on Fail” options in every node’s Settings tab that let the workflow keep running:

**Option 1: “Using Error Output”:** The node gets a separate error output connector (a red port). When the node fails, execution routes through this dedicated error output instead of the main success output. This is ideal for building explicit fallback branches: for example, if an API call fails, route to an alternative provider or send an alert. The success output only fires when the node succeeds, giving you clean branching with no ambiguity.

**Option 2: “Using Default Output”:** The node continues through its normal output, but the failed item’s JSON now contains an `error` object with details about the failure. To detect whether the node succeeded or failed, you have two approaches:

- Check for the error directly: `{{ $json.error }}`: if it exists, the node failed
- Check for an expected output key: `{{ $json.expected_key }}`: if it doesn’t exist, the node likely failed

Option 2 is useful when you want to handle success and failure in the same branch with a simple IF check, rather than splitting into separate error/success paths.

---

## Preventing Silent Workflow Stops: Guard Against Empty Results

Even when a node doesn’t technically “fail,” it can return zero results: and this silently stops downstream execution. The most common case is a database lookup (e.g., Supabase “Get a Row”) that finds no matching record. The node succeeds (no error), but outputs nothing, and every node after it simply never runs.

**The fix:** Add an IF node immediately after any lookup that might return empty, and check whether the result is an empty object:

```
{{ Object.keys($json).length === 0 }}
```

- **TRUE** (empty) → Handle the missing data case (create the record, send a notification, use a default value)
- **FALSE** (has data) → Continue with normal processing

This pairs with the “Always Output Data” setting (*Always Output Data: Handle Empty Lookups Gracefully*, in `data-flow-and-items.md`). With Always Output Data enabled, an empty result outputs `{}` instead of nothing, which keeps the item in the flow so your IF node can actually evaluate it. Without that setting enabled, the item vanishes entirely and the IF node never fires.

**Common places to add this guard:**

- After any Supabase/Postgres lookup
- After HTTP requests that may return empty bodies
- After search operations that might find zero matches
- After any node where “no result” is a valid, expected outcome that you need to handle

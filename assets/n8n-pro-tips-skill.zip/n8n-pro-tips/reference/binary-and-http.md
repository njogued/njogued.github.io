# Binary Data and HTTP

Binary data handling and HTTP-based model calls.

---

## Binary Data Downstream

When you need to pass binary data (images, files, etc.) to downstream nodes after it’s been fetched, standard `$json` references won’t work: you need to access the binary data explicitly.

---

### Method 1: Edit Fields Node

Use an Edit Fields node with this expression to reference binary data from an earlier node:

```
{{ $('REPLACE WITH NODE NAME').item.binary.data }}
```

---

### Method 2: Code Node (Buffer)

For creating binary data from scratch: for example, generating a Markdown file programmatically: use a Code node with a Buffer:

```jsx
const content = "# My Generated File\\n\\nContent here.";
const buffer = Buffer.from(content, "utf8");

return [
  {
    json: {},
    binary: {
      data: {
        data: buffer.toString("base64"),
        mimeType: "text/markdown",
        fileName: "output.md",
      },
    },
  },
];
```

---

### Method 3: Extracting Binary Data to Base64/Text (Code Node)

The reverse of Method 2: when you have an incoming file (from a webhook upload, Read Binary File, HTTP Request, etc.) and need to extract its contents as base64 or readable text.

> **Important:** Don’t access `binary.data.data` directly. n8n can store binary data in an external filesystem location (especially for larger files), so the base64 string may not be on the object. Always use n8n’s built-in helper.
> 

**Use `this.helpers.getBinaryDataBuffer()`**: this is the n8n-recommended approach. It handles both inline base64 and filesystem-stored binary data:

```jsx
// Run Once for Each Item mode
const buffer = await this.helpers.getBinaryDataBuffer(0, "data");
const meta = $input.first().binary?.data || {};

return {
  json: {
    base64: buffer.toString("base64"),
    textContent: buffer.toString("utf8"),
    fileName: meta.fileName || "unknown",
    mimeType: meta.mimeType || "application/octet-stream",
  },
};
```

**Key distinction:**

- `$input.first().binary.data` → gives you the **metadata object** (fileName, mimeType, etc.)
- `this.helpers.getBinaryDataBuffer()` → gives you the **actual file contents** as a Node.js Buffer

**The binary key name (`data`) must match what the upstream node used.** If a webhook or form upload created the binary, the key might be `file`, `attachment`, or the form field name. Check the upstream node’s output to confirm, or detect it dynamically:

```jsx
// Detect the binary key dynamically
const binaryKey = Object.keys($input.first().binary)[0];
const buffer = await this.helpers.getBinaryDataBuffer(0, binaryKey);
```

**For non-text files** (images, PDFs), skip `toString('utf8')` and work with the base64 string directly: that’s what you’d pass to an API like OpenAI’s vision endpoint or store in a database.

---

## HTTP Node: Always Return Binary Output

The HTTP Request node can be configured to **always return binary data**, even when the response might otherwise be interpreted as JSON or text. This is useful when downloading files (images, PDFs, etc.) and you need a guaranteed binary output shape for downstream nodes.

**How to set it:**
In the HTTP Request node, go to **Options** → set **Response Format** to **File** (binary). This forces the node to always output the response as binary data regardless of content type.

**Why it matters:**
Without this, the HTTP node may return JSON on some responses and binary on others, breaking downstream nodes that expect a consistent binary input. Forcing binary output ensures your workflow handles files predictably: a good complement to the “Always Output Data” setting (see *Always Output Data: Handle Empty Lookups Gracefully* in `data-flow-and-items.md`).

---

## OpenRouter for Vision: Multi-Model Fallback With One HTTP Call

> Companion to *HTTP Node: Always Return Binary Output* above. Use this when you want provider-level redundancy on image analysis without wiring up multiple AI nodes.
> 

**The Pattern:** OpenRouter accepts an array of model IDs in the `models` field and will automatically fall back to the next model in the list if the first one fails, errors, or returns nothing. This gives you provider-level redundancy for vision tasks (or any chat-completion task) with a single HTTP node: no Merge gates, no error branches between models.

---

### Why Use This Instead of Native Gemini / OpenAI Nodes

- **Provider redundancy in one call**: list 3 models, OpenRouter tries them in order
- **Cheap-first, premium fallback**: start with a fast/cheap model, fall back to a stronger one only if needed
- **Mix providers**: combine Qwen, Gemini, Claude, GPT in the same fallback chain
- **Uniform response shape**: OpenAI-compatible API, so `$json.choices[0].message.content` works regardless of which model actually answered

---

### Request Body Shape

```json
{
  "models": [
    "qwen/qwen3.5-plus-02-15",
    "google/gemini-2.0-flash-lite-001",
    "google/gemini-2.5-flash"
  ],
  "messages": [
    {
      "role": "user",
      "content": [
        { "type": "text", "text": "Describe this image..." },
        { "type": "image_url", "image_url": { "url": "{{ $json.dataUrl }}" } }
      ]
    }
  ],
  "stream": false
}
```

Key points:

- **`models` (array), not `model` (string)**: this is what enables the fallback chain
- **`content` is an array, not a string**: vision requests use multi-part content with `type: "text"` and `type: "image_url"` blocks
- **`image_url.url` accepts either an HTTPS URL or a base64 data URL**: data URLs are simpler when the image is already in the workflow as binary

---

### Preparing the Image as a Data URL

OpenRouter (following the OpenAI vision spec) expects `image_url` to be a string. A base64 data URL is the cleanest way to pass a binary that’s already in your workflow:

```jsx
// Code node: Run Once for Each Item
const buffer = await this.helpers.getBinaryDataBuffer(0, 'data');
const base64String = buffer.toString('base64');
const meta = $input.item.binary.data;

// Derive MIME type from filename: binary metadata's mimeType can be missing/stale
const ext = (meta.fileName || '').split('.').pop().toLowerCase();
const mimeMap = {
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  gif: 'image/gif',
  webp: 'image/webp'
};
const mimeType = mimeMap[ext] || meta.mimeType || 'image/png';

return {
  json: {
    dataUrl: `data:${mimeType};base64,${base64String}`,
    fileName: meta.fileName,
    mimeType
  }
};
```

Then reference `{{ $json.dataUrl }}` in the HTTP Request body. (See *Binary Data Downstream* above for the full binary-extraction discussion and why `this.helpers.getBinaryDataBuffer()` is the correct way to get bytes off binary metadata.)

---

### HTTP Request Node Configuration

- **Method:** POST
- **URL:** `https://openrouter.ai/api/v1/chat/completions`
- **Authentication:** Predefined credential type → OpenRouter API
- **Headers:** `Content-Type: application/json`
- **Body:** JSON (specify body as JSON, paste the request shape above)
- **On Error:** `continueErrorOutput`: so a hard failure (all models in the list errored) routes to your fallback branch

---

### Reading the Response

OpenRouter returns the OpenAI-compatible shape regardless of which model answered:

```
{{ $json.choices[0].message.content }}
```

If you want to know which model actually responded (for logging or cost tracking), it’s at `$json.model`.

---

### When OpenRouter’s Built-In Fallback Isn’t Enough

The `models` array handles provider/model failures gracefully, but it doesn’t catch every case. You may still want a downstream Merge-gated fallback (*Merge Node Modes: Append vs Combine*, in `merge-and-branching.md`) if:

- OpenRouter itself is down (the whole HTTP call fails)
- You want a non-OpenRouter fallback (e.g., a direct Gemini call as a last resort)
- You need to gate on response quality, not just success/failure (e.g., the model returned a refusal or an empty description)

In those cases, pair the OpenRouter `models` array with a Combine-merge fallback to a native node downstream. See *Merge Node Modes: Append vs Combine* in `merge-and-branching.md` for a worked example combining both patterns.

---

### Gotcha: Verify Model IDs Are Current

OpenRouter’s model catalog churns. Model IDs are dated snapshots and can be deprecated. Check `https://openrouter.ai/models` periodically and update the array. If the first model in your list is dead, you’re paying the latency cost of one failed attempt on every call before fallback kicks in.

---

## File Size Limits Will Crash Your Instance

Files that are too large cause out-of-memory errors. Process large files outside n8n where possible, and pass references (URLs, paths) rather than file contents through the workflow.

# Loops and Sub-Workflows

Loop mechanics, sub-workflow architecture, recursion, and throttling.

---

## Nested Loops Are Not Supported: Use Sub-Workflows

> **Severity: Critical.** This causes silent data loss with no error or warning.
> 

**The Problem:** n8n does not support loops within loops. If you place a loop inside another loop, the inner loop will only execute for the **first item** from the outer loop. All subsequent outer loop items are silently skipped: no error, no warning, just incomplete data.

---

### What Happens

```
Outer Loop: items [A, B, C]
  → Inner Loop runs for A ✅
  → Inner Loop silently fails for B ❌ (no error)
  → Inner Loop silently fails for C ❌ (no error)

Result: you think all 3 were processed. Only A was.
```

The workflow completes successfully. Executions show green. You only discover the problem when you check your data.

---

### Common Symptoms

- A **loop within a loop** only processes the first item from the outer loop
- Database records are only partially populated after a run
- Workflow shows no errors but output count doesn’t match expectations
- Inner loop results appear correct for the first item only

**Important:** The **Split Out** node itself works fine inside loops. The issue is specifically with **nested loops** (IF → loop back pattern inside another IF → loop back pattern).

---

### The Fix: Sub-Workflows

Replace the inner loop with an **Execute Sub-workflow** node. The inner loop logic lives in a separate workflow that gets called once per outer item.

```
❌ BROKEN: Nested loop:

Outer Loop (IF) → [Split Out → Inner Loop (IF) → Process] → Edit Fields → back to Outer Loop

✅ CORRECT: Sub-workflow pattern:

Outer Loop (IF) → Execute Sub-workflow → Edit Fields → back to Outer Loop
                        ↓
              [Sub-workflow: Split Out → IF → Process → done]
```

---

### How to Implement

**In the main workflow:**

1. Replace the inner loop entirely with an **Execute Workflow** node
2. Pass the item data needed by the inner logic as input parameters
3. The outer loop continues as normal after the sub-workflow returns

**In the sub-workflow:**

1. Trigger: **Execute Workflow Trigger** node
2. Build the inner loop logic (Split Out → IF → Process) as normal
3. Return results back to the main workflow if needed

---

### Why This Architecture Is Actually Better

Beyond fixing the bug, sub-workflows offer real advantages:

- Inner logic can be **tested and debugged independently**
- Sub-workflows can be **reused** across multiple parent workflows
- Cleaner, more maintainable workflow structure
- Easier to reason about data flow

---

## Wait Node + Sub-Workflows: Parallel Processing for Approval Flows

**The Problem:** If you build an approval flow (e.g. draft email responses, then get Slack approval before sending) in a single sequential workflow with a Wait node, the workflow halts completely on the first item until the approval times out or is actioned. With 10 items, each with a 10-minute wait, you could be waiting 100+ minutes to process everything.

---

### The Pattern

Use a **sub-workflow** instead, and configure the main workflow to **not wait** for the sub-workflow to complete before moving to the next item.

```
Main Workflow:
  [Trigger] → [For Each Item] → [Execute Sub-workflow (don't wait)] → [next item...]

Sub-workflow (runs independently per item):
  [Trigger] → [Draft response] → [Wait node] → [Send approval to Slack] → [Wait for response] → [Send / Discard]
```

With this setup:

- All 10 items fire off their sub-workflows simultaneously
- All 10 draft messages arrive in Slack at the same time
- You approve/reject them all in one batch, not one by one

---

### Key Configuration

In the **Execute Workflow** node, set **“Wait for sub-workflow”** to **OFF**. This tells the main workflow to continue to the next item immediately rather than waiting for the sub-workflow to finish.

---

### When to Use This

Any time you have a flow where:

- You process multiple items
- Each item requires a human action or an external wait (approval, webhook callback, scheduled send)
- You want all items to be “in flight” simultaneously rather than sequentially

---

## Loops + Wait Node: Handling Rate Limits

**The Problem:** Running a long task against an API in a straight sequence will hit rate limits. For example, fetching full Slack threads for 500+ messages in one go will likely fail partway through.

---

### The Pattern

Use a **Loop node** (Split in Batches) combined with a **Wait node** to pace your requests.

```
[Items] → [Split in Batches: 10] → [API Call] → [Wait: 3s] → ↩ loop
```

**Example calculation for Slack (20 requests/minute limit):**

- 60 seconds ÷ 20 requests = 3 seconds per request
- Set Wait node to **3 seconds** to stay safely within limits

Adjust batch size and wait time based on the API’s rate limit documentation.

---

### Also Useful For

- Supabase bulk operations where you want to avoid overloading the database
- Any external API with a requests-per-minute cap
- Large-scale data processing where you want predictable, throttled execution

---

## Recursive Sub-Workflows: API Pagination Without Loops

**The Problem:** Some APIs return paginated results with a cursor or `has_more` flag. You don’t know how many pages exist upfront, so a fixed loop won’t work. Building a loop-back pattern inside a single workflow risks the nested loop issues from *Nested Loops Are Not Supported* above if other loops are already present.

---

### The Pattern

An **Execute Workflow** node calls **its own workflow ID**, creating clean recursion. Each execution handles one page and passes the next cursor to itself. An IF node checks the termination condition and either recurses or exits.

```
[Execute Workflow Trigger] → [Fetch Page (HTTP Request)] → [Process Results] → [IF: more pages?]
  TRUE  → [Execute Workflow: THIS workflow's ID, pass next cursor + depth] → [Return combined results]
  FALSE → [Return final results]
```

Each recursive call is its own isolated execution context: no data bleed, no nested loop issues. Results bubble back up through the return chain.

---

### Key Configuration

- **Execute Workflow node**: set the workflow ID to the current workflow’s own ID
- **Pass parameters**: send the pagination cursor/offset and a depth counter as input fields
- **Execute Workflow Trigger**: receives cursor and depth, uses them to fetch the next page
- **IF node**: checks both `has_more` (or equivalent) AND depth limit

---

### Safety: Always Include a Depth Counter

APIs can return `has_more: true` indefinitely if something goes wrong. Always pass a `depth` parameter that increments each call, and include it in the termination condition:

```
{{ $json.has_more === true && $json.depth < 50 }}
```

Without this, a misbehaving API will trigger infinite recursion: burning through executions and potentially hitting n8n’s execution limits.

---

### When to Use This Over a Simple Loop

- **Unknown page count**: you can’t set a fixed loop size
- **Workflow already contains a loop**: adding another would create nested loops (see *Nested Loops Are Not Supported* above)
- **Clean separation**: each page fetch is independently debuggable in execution history
- **Complex per-page processing**: each execution can do heavy transforms without accumulating memory

For simple, bounded pagination (known page count, no existing loops), a standard SplitInBatches + Wait loop (*Loops + Wait Node: Handling Rate Limits* above) is simpler.

---

## Fixed-Count Loops (Circuit Breaker Pattern)

n8n doesn’t have a native “repeat N times” node. Use an IF node + counter: add a `run` field that increments each pass (`={{ ($('If').item.json.run || 0) + 1 }}`), then add an IF condition to exit when `run` reaches your max (e.g., `{{ ($json.run == null) || ($json.run != null && $json.run < 10) }}`). This acts as a circuit breaker to prevent infinite loops. Always include this on any loop: an unterminated loop will crash your instance with an out-of-memory error.

---

## Unterminated Loops Will Crash Your Instance

Always include a counter circuit breaker in loops (see above). An infinite loop will consume all available memory and bring down the instance.

# Nodes and Models

Node selection and model-provider limits.

---

## Useful Internal Nodes

These built-in n8n nodes are often overlooked but save significant time:

**Sort**: Sort items by any field, ascending or descending. Avoids writing custom sort logic in Code nodes.

**Limit**: Cap the number of items flowing through. Useful for testing (process only first 5) or enforcing maximums.

**Deduplication Node**: Remove duplicate items based on a key field. Essential for idempotent workflows that might receive the same data twice.

**Code Node**: JavaScript or Python for custom logic. Use as a last resort: check if a built-in node (Sort, Deduplicate, etc.) already solves your problem first.

**Edit Fields (Set)**: Normalize and reshape data. Prefer this over Code nodes for simple field mapping; it’s visually clear and easier to modify later.

**No-Op Node (Do Nothing)**: Acts as a flow control junction. When multiple branches converge back into a single loop, use a No-Op to collect all branches cleanly before the loop continues. Makes complex flows much easier to read.

```
Branch A ─┐
Branch B ──→ [No-Op] → [Loop back / Continue]
Branch C ─┘
```

---

## When a Node Doesn’t Exist or Doesn’t Do What You Need

If n8n doesn’t have a native node for a service, or the existing node is too limited, here are your options in order of ease vs. power:

**Option 1: HTTP Request Node (easiest)**
Most APIs have REST endpoints. The HTTP Request node can call any API with full control over headers, authentication, and body. Check the service’s API docs and build the call manually.

**Option 2: Apify (more powerful, harder to configure, may cost money)**
For web scraping and browser automation tasks. More capable than HTTP Request for dynamic pages, but requires setup and has usage costs.

**Option 3: Browser Simulation (most powerful, hardest to maintain)**
Full browser automation for services with no API or that require human-like interaction:

- **Anchor Browser**
- **Browser-Use**
- **Browser Base**

These are the most capable but also the most brittle: any UI change in the target service can break your automation.

---

## Gemini Output Formatting Limitations

> Ref: [Why Google Gemini’s Response Schema Isn’t Ready for Complex JSON](https://ubaidullahmomer.medium.com/why-google-geminis-response-schema-isn-t-ready-for-complex-json-46f35c3aaaea)
> 

Gemini has significant limitations with complex JSON schema definitions in n8n’s Structured Output Parser. These can cause cryptic, hard-to-debug errors.

---

### Known Unsupported Patterns

Nullable fields using JSON Schema union syntax are **not supported**:

```json
❌  { "type": ["string", "null"] }
```

This produces errors like:

- `"Proto field is not repeating, cannot start list"`
- `"Unknown name 'type' at 'path'"`

---

### Workarounds

**Use Gemini’s nullable syntax instead:**

```json
✅  { "type": "string", "nullable": true }
```

**For complex schemas**: define the output structure in the prompt text itself rather than in the schema definition, then use a separate downstream step to parse and validate:

```
[Gemini Agent: output defined in prompt]
  → [OpenAI LLM Chain: parse/fix the output schema]
  → [Structured Output Parser]
```

**General rule:** For anything involving complex nested schemas or nullable fields, route to **OpenAI** instead of Gemini. OpenAI handles these more reliably in n8n.

---

## Check for a Built-In Node Before Writing a Code Node

Sort, Deduplicate, Limit, Merge, Split Out: these cover many cases that feel like they need custom code.

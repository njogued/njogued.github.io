# Data Flow and Items

Item linking, item counts, Code node contracts, and expression guards.

---

## Recovering Lost Data Links

**The Problem:** After passing data through a Code node or certain transformations, you lose the reference to data from earlier in the workflow. Downstream expressions like `$('Node Name').json.some_field` no longer work as expected.

---

### Solution 1: Reference a Specific Earlier Node

Use `$('Node Name').first().json` or `$node['Node Name'].json` to explicitly pull data from an earlier node by name, bypassing the “current item” context entirely.

```jsx
// Pull from a specific earlier node
{
  {
    $("Set Message Fields").first().json.channel_id;
  }
}
```

---

### Solution 2: JavaScript Filter to Match the Right Item

When you have multiple items and need to find the one that corresponds to the current item, use `.all().filter()`:

```jsx
{
  {
    $("Set Message Fields")
      .all()
      .filter((ms) => ms.json.ts === $json.message_id)[0].json.text;
  }
}
```

This is useful when a Code node breaks the 1:1 item pairing and you need to re-establish the relationship by matching on a shared key (like a message ID or timestamp).

---

### Solution 3: `.map()` for Array Transformations

JavaScript’s `.map()` is helpful when you need to transform an array of items, e.g.:

```jsx
{
  {
    $("Get Channels")
      .all()
      .map((item) => item.json.channel_name);
  }
}
```

### Solution 4 - pairedItem & itemMatching: Preserving Data Links in Code Nodes

**The Problem:** Code nodes break n8n’s internal item-to-item linking. After a Code node, downstream nodes can no longer trace which output item corresponds to which input item. This is the root cause of the data linking issues described above.

---

### pairedItem: Preserve Links Through Code Nodes

When returning items from a Code node, use the `pairedItem` property to tell n8n which input item each output item corresponds to:

```jsx
// "Run Once for All Items" mode
const items = $input.all();

return items.map((item, index) => ({
  json: {
    // your transformed data
    processed: item.json.someField.toUpperCase(),
  },
  pairedItem: index, // links this output to input item at same index
}));
```

This preserves the chain so that nodes further downstream can still reference data from nodes **before** the Code node using standard expressions.

---

### itemMatching: Access Linked Items from Earlier Nodes

When you need to access the linked item from an earlier node (after pairedItem has preserved the link), use `itemMatching`:

```jsx
// Access the paired item from a specific earlier node
const earlierData = $("Earlier Node Name").itemMatching($input.item);
```

This is the n8n-native alternative to the manual `.all().filter()` workaround in Solution 2 above. It’s cleaner, less error-prone, and doesn’t require you to manually match on shared keys.

---

### When to Use Each

- **pairedItem**: Use in every Code node where you’re transforming items and want to maintain linkage for downstream nodes
- **itemMatching**: Use downstream of a Code node (that used pairedItem) when you need to pull data from a node that came before the Code node
- **The Solution 1–3 workarounds above**: Still useful as a fallback when pairedItem wasn’t set, or for complex many-to-many relationships

---

## Always Output Data: Handle Empty Lookups Gracefully

**The Problem:** When a lookup node (e.g. Supabase “Get a row”) finds no matching record, it outputs nothing: the item disappears from the flow entirely. This makes it impossible to handle the “not found” case in the same workflow branch.

This is particularly relevant for **Supabase**, which does not support native upsert operations, making the “check if exists → create or update” pattern very common.

---

### The Setting

On any node that might return empty: go to **Settings** tab → enable **“Always Output Data”**.

When enabled, if the node returns no results, it outputs an **empty JSON object `{}`** instead of nothing. The item stays in the flow, and you can route it conditionally.

---

### The Pattern: Create or Update (Manual Upsert)

```
[Get a row]  ← Always Output Data: ON
     ↓
  [IF node] : does row exist?
  TRUE ↓              FALSE ↓
[Update row]      [Create row + Slack notify]
```

**IF condition to check for empty result:**

```
={{ Object.keys($json).length > 0 }}
```

- Returns `true` → row exists, update it
- Returns `false` → row is empty `{}`, create it

---

### Real-World Example: Supabase Channel Tracking

For each Slack channel:

1. **Get a row** (Supabase): look up channel by ID. Always Output Data: **ON**
2. **IF**: `Object.keys($json).length > 0`
    - **TRUE** → row exists → **Update row** with latest data
    - **FALSE** → row doesn’t exist → **Insert row** + **Slack notification** (new channel detected)

Without Always Output Data, the FALSE branch would never trigger: items simply vanish when not found.

---

### Nodes Where This Is Most Useful

- Supabase / Postgres “Get a row” or “Select” with 0 results
- HTTP Request returning empty body
- Any lookup that may legitimately return nothing

---

### ⚠️ Critical Caveat: Always Output Data Is Node-Level, Not Per-Item

> **Severity: High.** The manual-upsert pattern above silently breaks when you feed the lookup more than one item at a time.
> 

"Always Output Data" does **not** guarantee one output item per input item. It is a node-level fallback that only fires when the node produces **zero total output across the entire run.** It has no per-item awareness. This is general lookup-node behavior (Supabase `getAll`, Postgres, the Notion node, etc.), not specific to one provider.

Two distinct failure modes when multiple items flow into a single lookup:

**Mixed run (some match, some don't):**

```
Input: [Post A (exists), Post B (new)]
  → [Get rows]  ← Always Output Data: ON
  → Output: [Post A's row]   ← Post B silently dropped, NO {} placeholder
```

The node produced output for the matches, so the fallback never triggers. Post B does not become an empty `{}`. It just vanishes. The FALSE branch never sees it.

**Fully empty run (nothing matches):**

```
Input: [Post A (new), Post B (new)]
  → [Get rows]  ← Always Output Data: ON
  → Output: [ {} ]   ← ONE empty object, not one per input item
```

You get a single `{}` for the whole node, not one `{}` per input. Item count collapses from 2 to 1.

---

### Why the Always Output Data Pattern Still Works (and When It Doesn't)

The manual-upsert pattern is only safe when the lookup processes **one item at a time** (inside a loop, or per-item execution). In that mode, "zero total output" and "this item didn't match" are the same condition, so the `{}` fallback correctly stands in for each missing item.

Fan multiple items into one lookup and that equivalence breaks. The per-item FALSE branch can no longer be trusted.

---

### The Fix

**Process one item at a time.** Keep the lookup inside a loop (or per-item execution) so each "not found" is its own zero-output run, and the `{}` fallback correctly stands in for each missing item. Slower than a single batched query for large inputs, but it keeps the per-item branch logic valid.

---

## The “Execute Once” Setting

Every n8n node has an **“Execute Once”** toggle in its Settings tab. When ON, the node runs only for the **first input item** regardless of how many items are passed in.

**When Execute Once is actually useful:**

- Triggering a single notification regardless of how many items came in
- Calling an API that doesn’t depend on item data (e.g. fetching a config once)
- Inserting a single summary record, not one per item

**Rule of thumb:** If the node references `$json` (i.e. it uses current item data), Execute Once should almost certainly be **OFF**. If it doesn’t reference item data at all, Execute Once may be appropriate.

---

## Code Node Return Formats

> **Severity: High.** Incorrect return format causes `A 'json' property isn't an object [item 0]` errors.
> 

The return format depends on the Code node’s execution mode. Getting this wrong produces runtime errors.

---

### “Run Once for Each Item” Mode

Return a **single object** with a `json` key. Do **not** wrap in an array.

```jsx
// ✅ CORRECT: single object
return {
  json: {
    name: "example",
    value: 42,
  },
};
```

```jsx
// ❌ WRONG: array wrapper causes errors in this mode
return [
  {
    json: {
      name: "example",
      value: 42,
    },
  },
];
```

**Restrictions in this mode:**

- `$input.all()` is **not available**: n8n only exposes the current item
- Use `$input.first()` or `$input.item` to access the current item

---

### “Run Once for All Items” Mode

Return an **array of objects**, each with a `json` key.

```jsx
// ✅ CORRECT: array of objects
return [{ json: { name: "item1" } }, { json: { name: "item2" } }];
```

**Both `$input.first()` and `$input.all()` are available in this mode.**

---

### Returning Binary Data

When returning binary alongside json, the `json` key must still be a valid object (even if empty):

```jsx
// "Run Once for All Items" mode: array with binary
return [
  {
    json: {},
    binary: {
      data: {
        data: buffer.toString("base64"),
        mimeType: "text/markdown",
        fileName: "output.md",
      },
    },
  },
];

// "Run Once for Each Item" mode: single object with binary
return {
  json: {},
  binary: {
    data: {
      data: buffer.toString("base64"),
      mimeType: "text/markdown",
      fileName: "output.md",
    },
  },
};
```

---

### Common Pitfall

The error `A 'json' property isn't an object [item 0]` usually means one of:

- The `json` value is `null`, `undefined`, a string, or a number instead of a plain object
- Destructuring failed silently (e.g., `$input.first().binary?.data` returned `undefined` and downstream code put a non-object into `json`)
- Wrong return format for the selected mode (array vs. single object)

**Always add safety checks** when building json from potentially missing data:

```jsx
const meta = $input.first().binary?.data || {};

return {
  json: {
    fileName: meta.fileName || "unknown",
    mimeType: meta.mimeType || "application/octet-stream",
  },
};
```

---

## Referencing Unexecuted Nodes: The `$if` Guard

**The Problem:** If an expression references a node that didn’t execute in the current run (e.g., it’s on a branch that was skipped), n8n throws a warning: *“An expression references this node, but the node is unexecuted.”* This can cause unexpected empty values or errors downstream.

---

### The Fix

Use `$if()` with `.isExecuted` to check whether the referenced node actually ran before pulling data from it:

```
{{ $if($("NodeName").isExecuted, $("NodeName").first().json.value, "") }}
```

- If `NodeName` executed → returns its data
- If `NodeName` did **not** execute → returns the fallback (empty string, default value, etc.)

---

### When to Use This

- **After branching logic (IF/Switch)**: when downstream nodes reference data from branches that may not have fired
- **Merge nodes collecting from optional branches**: where one or more inputs may be absent
- **Error fallback patterns**: where you reference both success and error path nodes but only one runs per execution

---

### Real-World Example: Conditional Data Merge Without a Merge Node

A common pattern is an IF node that checks whether data already exists on the incoming item. If it does, skip the lookup; if not, fetch and build it. Both branches converge on the **same downstream node**, which uses `$if(.isExecuted)` to resolve which branch actually ran.

```
[IF: userMap exists?]
  TRUE  ──────────────────────────────┐
  FALSE → [Supabase: Get Users] → [Assign Users to IDs] ──→ [Create User Map]
                                                               ↑
                                                     (both branches feed here)
```

The “Create User Map” node uses a single expression to handle both cases:

```
={{
  $('Assign Users to IDs').isExecuted
    ? Object.assign({}, ...$('Assign Users to IDs').all().map(i => i.json))
    : $('Set Date and Channel Details').item.json.userMap
}}
```

- If “Assign Users to IDs” executed (FALSE branch ran) → build the map from the freshly fetched results
- If it didn’t (TRUE branch ran) → pull the pre-existing `userMap` from the incoming item

This avoids the Merge node entirely: no worrying about Combine vs Append modes (*Merge Node Modes: Append vs Combine*, in `merge-and-branching.md`), and no extra nodes. Works well when the data shape is simple enough that a single expression can resolve the “which source?” question.

---

## JavaScript Expressions Are Powerful: Use Them

The expression editor supports full JS. Key examples:

- Time operations: `{{ $now.minus({ hours: 24 }).toISO() }}`
- Array `.map()` and `.filter()` for inline data transformation
- `JSON.stringify($json)` to serialize objects for passing to APIs or prompts

# Supabase and Postgres

Supabase and Postgres node behaviour, connection setup, and SQL migration.

---

## PostgREST Query Params in the Supabase Node’s filterString

**The Problem:** The Supabase node (typeVersion 1) doesn’t natively support `order`, `limit`, or other PostgREST query parameters: only filters. So getting the “latest row” or ordering results previously required dropping down to an HTTP Request node hitting the PostgREST API directly.

---

### The Discovery

The Supabase node’s `filterType: "string"` option passes the raw string directly to the PostgREST API. You can **append any PostgREST query parameter** to the filter string: not just filter conditions. The node doesn’t validate or strip them.

---

### Example: Get Unprocessed Weekly Digests, Ordered by Date

```json
{
  "operation": "getAll",
  "tableId": "internal_weekly_slack_digest",
  "returnAll": true,
  "filterType": "string",
  "filterString": "=and=(channel_id.eq.{{$json.channel}},projects_classified.is.null)&order=digest_date.asc"
}
```

This sends a single request that filters AND orders in one shot: entirely within the Supabase node.

---

### What You Can Append

- `&order=column.asc` or `&order=column.desc`: sorting
- `&limit=1`: return only N rows
- `&order=created_at.desc&limit=1`: **“get latest row” pattern**
- `&select=col1,col2`: column selection (reduce payload size)

---

### Important: Set `returnAll: true`

When using `&limit=` in the filterString, set `returnAll: true` on the node. Otherwise the node’s own pagination logic may conflict with your manual limit and produce unexpected results.

---

### When to Still Use HTTP Request → PostgREST Directly

- Complex `or()` logic across multiple columns
- Range queries (`Range` header for pagination)
- When you need response headers (e.g., `Content-Range` for total count)
- RPC calls (`/rpc/function_name`)
- Any case where you need full control over the HTTP request

---

## Supabase Postgres Connections: Always Use the Transaction Pooler

> **Severity: High.** Wrong port = pool exhaustion under real workflow traffic. The smoking-gun error is `EMAXCONNSESSION max clients reached in session mode - max clients are limited to pool_size: 15`.
> 

**The Problem:** Supabase exposes Postgres through three different connection endpoints. All three “work” in basic testing: the difference only surfaces once you have any concurrency. Pick the wrong one and n8n workflows will silently degrade, then crash under load. The fix is a one-character change (the port), but it’s invisible until production traffic hits.

---

### The Three Endpoints

| Connection Type | Host | Port | Use Case |
| --- | --- | --- | --- |
| Direct connection | `db.<project>.supabase.co` | 5432 | Long-running services, migrations. **Not for n8n.** |
| Session pooler | `aws-0-<region>.pooler.supabase.com` | 5432 | Persistent sessions, prepared statements. **Not for n8n.** |
| Transaction pooler | `aws-0-<region>.pooler.supabase.com` | **6543** | n8n, serverless, anything bursty. **Use this.** |

The session and transaction poolers share the same hostname. The **port** is the only thing that distinguishes them.

---

### Why n8n Specifically Needs Transaction Mode

n8n’s execution model creates a connection per node run, holds it for the duration of that node, and releases. Under any real traffic (Slack triggers, scheduled workflows, webhooks firing in parallel), you’ll have many short-lived connections.

- **Session mode**: connection assigned to a client for the entire session. The 15-connection pool exhausts almost immediately once executions overlap.
- **Transaction mode**: connection returned to the pool after each transaction. Same 15-connection pool can serve hundreds of concurrent executions.

The default Supabase pool size (15) is fine for transaction mode. Increasing the pool isn’t usually the right fix: switching modes is.

---

### Decoding the Error

```
(EMAXCONNSESSION) max clients reached in session mode - max clients are limited to pool_size: 15
```

- `EMAXCONNSESSION`: Supabase’s pooler signaling client connection limit reached
- `session mode`: confirms you’re on port 5432 of the pooler
- `pool_size: 15`: the default per-project pool, not the bottleneck (transaction mode handles the same pool size fine)

When you see this error in n8n logs, the diagnosis is always the same: **wrong port**. Don’t increase the pool size, don’t add retries, don’t add Wait nodes between Postgres calls: switch to port 6543.

---

### Where to Find the Right Connection String

Supabase Dashboard → click the **“Connect”** button at the top of any project page. You’ll get a modal with three tabs (Direct, Transaction, Session). Copy the transaction pooler string.

Alternatively: Project Settings → Database → “Connection string” section, same tabs there.

Note: the “Connection pooling” settings page (pool size, max clients) does **not** show the connection strings. That page is for configuring pool behavior, not retrieving credentials.

---

### The n8n Credential Setup

For the Postgres credential in n8n:

- **Host**: `aws-0-<region>.pooler.supabase.com` (region matches your Supabase project)
- **Port**: `6543` ← this is the entire point
- **Database**: `postgres`
- **User**: `postgres.<project_ref>`
- **Password**: from Supabase dashboard
- **SSL**: Allow / Require (Supabase enforces TLS)

---

### Trap: PostgREST/Supabase Node Hides This Class of Issue

The native n8n Supabase node calls PostgREST over HTTPS, so this whole class of issue is invisible there. You won’t notice the pooling problem until you migrate to the Postgres node. **Plan for the credential setup as part of any Supabase → Postgres node migration (see *Supabase Node → Postgres Node Migration* below).**

---

### Sneakier Symptom: Intermittent Production Failures

Workflows succeed in manual testing but fail intermittently in production. If you see Postgres node errors clustering during high-traffic windows (Slack activity spikes, scheduled batch runs, webhook bursts), the pooler port is the first thing to check: even if the error message isn’t exactly `EMAXCONNSESSION`. Pool exhaustion can also surface as generic timeouts or `connection terminated unexpectedly` errors when the pooler kills queued connections.

---

### Edge Cases Where You’d Use Session Mode Instead

Almost never, in an n8n context. Session mode is for:

- Prepared statements (rare in n8n; the Postgres node uses parameterized queries, not prepared)
- `LISTEN/NOTIFY` (you’d use the Postgres Trigger node for this, separate connection lifecycle)
- Long-running transactions spanning multiple queries (uncommon in workflow logic)

If you’re not doing any of these, transaction mode is correct.

---

## Postgres Node: `queryReplacement` Comma-Splitting Bug

> **Severity: High.** Silent data corruption. Values shift positions and land in the wrong columns. Manifests as cryptic SQL type errors like `invalid input syntax for type double precision: "false"`.
> 

**The Problem:** The Postgres node’s `executeQuery` operation with `queryReplacement` does NOT do smart parsing of expressions. When you write:

```
={{ $json.field1 }},{{ $json.field2 }},{{ $json.field3 }}
```

n8n evaluates the whole expression to a single string, then splits the **resolved string** on every literal comma. If any of those values contains a comma in its data (URL lists, message text with punctuation, full names like “Smith, John”, job titles), each comma in the value becomes a fake parameter boundary. All subsequent parameter positions shift.

---

### What Failure Looks Like

Suppose the attachments field resolves to a list of 4 URLs joined by commas. Your 13-parameter query suddenly has 16 values (4 URLs counted as 4 separate params). Result: `$6` becomes the first URL, `$7` becomes the second URL instead of `channel_id`, everything downstream shifts.

When the shifted parameter lands in a typed column, you get a cast error:

```
invalid input syntax for type double precision: "false"
```

The string `"false"` here was the `is_edited` boolean from `$10`, now landing in position `$12` where the query does `to_timestamp($12::double precision)`.

The error message is misleading: it suggests a type problem, but the root cause is a positional problem upstream.

---

### The Fix: Return a JS Array Instead of a String

Wrap the values in an actual JS array expression:

```
={{ [$json.field1, $json.field2, $json.field3, $json.attachments_list, $json.message_text] }}
```

When n8n’s Postgres node sees `Array.isArray(value) === true`, it uses the array entries as positional parameters directly. **No string splitting.** Commas inside any value stay where they belong.

---

### Side-by-Side

```jsx
// ❌ BROKEN: string with commas, gets split on resolved commas
queryReplacement: "={{ $json.message_ts }},{{ $json.content }},{{ $json.attachments }}"

// ✅ CORRECT: JS array expression, used directly
queryReplacement: "={{ [$json.message_ts, $json.content, $json.attachments] }}"
```

---

### When This Bites You Hardest

Any field that can contain a comma in its data:

- **User-generated text**: message content, descriptions, comments, full names, job titles
- **URL lists**: anything that uses `array.join()` defaulting to comma separator
- **CSV-like data**: already-delimited values being passed through

If your workflow ever stores Slack messages, user profiles, or any free-text input, **use the array form by default**. The string form only works safely when every single value is a known non-comma type (IDs, booleans, ISO timestamps, numbers).

---

### When the String Form Is Fine

- All parameters are known to be comma-free (Slack channel IDs, user IDs, booleans, ISO timestamps)
- Quick prototyping with hardcoded values
- Test queries with literal values

Even then, the array form is safer and the syntax is barely different. Prefer the array form universally.

---

### Diagnosing in the Wild

Symptoms that point at this bug:

- `invalid input syntax for type X` errors where the value clearly doesn’t match the column type
- Values appearing in unexpected columns (URLs in `channel_id`, timestamps where text should be)
- A query that works in development but fails in production (because dev data didn’t contain commas)
- Errors that disappear when you remove the offending field but reappear when you add it back

Quick check: inspect the node’s resolved input. If you see your values strung together with commas as one big text blob, you’re looking at the string form. Switch to array form.

---

## Supabase Node → Postgres Node Migration

> **Origin story.** This entry exists because we hit recurring `Service unavailable - try again later` errors on the Supabase node in production. Direct Postgres queries against the same database worked fine. Diagnosis: PostgREST (the HTTP gateway the Supabase node calls) was flaking under load, not Postgres itself.
> 

**The Problem:** The native n8n Supabase node communicates with the database via PostgREST over HTTPS. PostgREST is a separate service in Supabase’s stack and is the flakiest layer. When it has a bad day, your workflows get `Service unavailable - try again later or consider setting this node to retry automatically (in the node settings)` errors. Direct Postgres connections bypass PostgREST entirely and have been rock-solid in our experience.

---

### When to Migrate

**Migrate now:**

- Workflows currently throwing `Service unavailable` errors from the Supabase node
- New workflows being built (default to Postgres node going forward)
- Workflows needing complex operations PostgREST doesn’t handle well: JOINs, CTEs, transactions, `RETURNING` clauses
- Workflows with manual upsert hacks (the insert-then-update-on-error pattern in *Always Output Data: Handle Empty Lookups Gracefully*, in `data-flow-and-items.md`): collapse into `INSERT ... ON CONFLICT` with one node
- Bulk operations where performance matters

**Leave alone:**

- Working Supabase node workflows with no errors: not worth the migration risk
- Workflows that lean heavily on the `filterString` PostgREST tricks above (translation cost is real, see below)

---

### What You Gain

- **Reliability**: one fewer service in the path. PostgREST is the flakiest layer.
- **Native upserts**: `INSERT ... ON CONFLICT (col) DO UPDATE SET ...` kills the manual upsert hack
- **Full SQL**: JOINs, CTEs, transactions, `RETURNING`, window functions
- **Better bulk performance**: direct connection is noticeably faster for batch ops
- **Cleaner expressions**: column mapping via SQL is more readable than nested PostgREST query params

---

### What You Lose

- **The `filterString` PostgREST trick (*PostgREST Query Params in the Supabase Node’s filterString*, above)**: replaced by SQL `WHERE` / `ORDER BY` / `LIMIT`, which is arguably cleaner but requires rewriting any workflow that relied on it
- **Row Level Security**: direct connections authenticate as a database role, RLS policies don’t apply. Fine for internal automation, but worth being explicit. Never expose direct Postgres credentials beyond n8n.
- **The visual operation picker**: every read/write is SQL. Less friction for SQL-comfortable users, more friction for others.
- **Migration cost**: every Supabase node needs rewriting

---

### Configuration Trap: Use the Transaction Pooler

The single most important config decision. **See *Supabase Postgres Connections: Always Use the Transaction Pooler* above for the full breakdown.** Short version:

- Use `aws-0-<region>.pooler.supabase.com` on **port 6543** (transaction mode)
- NOT port 5432 (direct connection or session mode)
- Default pool size (15) is fine

Get this wrong and the migrated workflow will work in testing then crash under real traffic with `EMAXCONNSESSION`.

---

### Per-Operation Translation Reference

**Read all rows:**

```sql
-- Old (Supabase node): operation=getAll, returnAll=true, tableId=my_table
-- New (Postgres node, executeQuery):
SELECT col1, col2, col3 FROM my_table;
```

**Read with filter and order:**

```sql
-- Old (Supabase node + the filterString trick above):
-- "and=(status.eq.active,deleted_at.is.null)&order=created_at.desc&limit=10"
-- New (Postgres node, executeQuery):
SELECT * FROM my_table
WHERE status = 'active' AND deleted_at IS NULL
ORDER BY created_at DESC
LIMIT 10;
```

**Insert with returned ID:**

```sql
-- Old (Supabase node): operation=create, then downstream uses $json.id
-- New (Postgres node, executeQuery):
INSERT INTO my_table (col1, col2) VALUES ($1, $2) RETURNING id, col1, col2;
```

**Upsert (the big win):**

```sql
-- Old (Supabase node): manual hack: Insert → IF on error → Update fallback. 3 nodes.
-- New (Postgres node, executeQuery): 1 node.
INSERT INTO my_table (id, col1, col2) VALUES ($1, $2, $3)
ON CONFLICT (id) DO UPDATE SET
  col1 = EXCLUDED.col1,
  col2 = EXCLUDED.col2;
```

**Idempotent insert (won’t error on duplicate):**

```sql
INSERT INTO my_table (id, col1) VALUES ($1, $2)
ON CONFLICT (id) DO NOTHING;
```

**Update by condition:**

```sql
-- Old (Supabase node): operation=update, filters
-- New (Postgres node, executeQuery):
UPDATE my_table SET col1 = $1, updated_at = NOW() WHERE id = $2;
```

**Conditional insert (only if FK row exists):**

```sql
-- Useful when a child table has an FK to a parent that may not be tracked yet
-- (e.g., only log messages for channels that already exist in internal_slack_channels)
INSERT INTO child_table (col1, col2, parent_id)
SELECT $1, $2, $3
WHERE EXISTS (SELECT 1 FROM parent_table WHERE id = $3)
ON CONFLICT (col1) DO UPDATE SET col2 = EXCLUDED.col2;
```

---

### Required Prerequisites Before Migrating a Workflow

1. **Postgres credential configured** with transaction pooler (*Always Use the Transaction Pooler*, above). Confirm port `6543`.
2. **Unique constraints exist** on any column you’re using as an `ON CONFLICT` target. Check with:
    
    ```sql
    SELECT conname, conrelid::regclass, pg_get_constraintdef(oid)
    FROM pg_constraint
    WHERE conrelid = 'my_table'::regclass AND contype IN ('u', 'p');
    ```
    
3. **Backup the workflow** by duplicating it in the n8n UI (right-click → Duplicate). Migrate the duplicate. Swap names when verified.
4. **Map all expressions** that reference `$json.id` or other returned fields from the Supabase node: ensure the new SQL has `RETURNING` to preserve those references.

---

### Parameter Binding Gotcha

When passing values to `executeQuery`, use the **JS array form** for `queryReplacement` (see *Postgres Node: `queryReplacement` Comma-Splitting Bug* above) to avoid the comma-splitting bug:

```jsx
// ✅ Safe for any value, including text with commas
queryReplacement: "={{ [$json.field1, $json.field2, $json.message_content] }}"
```

---

### Settings to Preserve Manually

The MCP API can set most node parameters but not all. After creating the new Postgres nodes, manually verify in the n8n UI:

- **Retry On Fail**: re-enable on critical write nodes (was on the original Supabase nodes)
- **Wait Between Tries**: preserve any custom value (typically 5000ms)
- **On Error**: `Continue (using regular output)` for non-critical writes, `Stop workflow` for critical paths

These are under each node’s **Settings** tab (not the parameters panel).

---

### When NOT to Migrate

- The workflow is working fine: don’t fix what isn’t broken
- The workflow uses Supabase-specific features (RPC functions called via Supabase node, etc.): these are translatable but the lift might not be worth it
- The team isn’t SQL-comfortable: manageability matters too

The right migration strategy is incremental: new workflows default to Postgres node, broken workflows migrate immediately, working Supabase workflows stay until they break or until a refactor opportunity comes up.

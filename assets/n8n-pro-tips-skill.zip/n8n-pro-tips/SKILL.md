---
name: n8n-pro-tips
description: Field-tested n8n fixes for building and debugging workflows - silent failures, nested loops, lost item links, Merge node modes, Code node errors, binary data, Supabase and Postgres traps.
---

# n8n Pro-Tips

Field-tested entries on n8n failure modes and patterns, from production client
work. Each entry lives in one reference file under `reference/`.

## How to route

Read this index, pick **one** reference file, open it. Do not open all six.

1. If the user quotes an error string or describes a symptom, use the
   **Symptom lookup** table below. It is the fastest path.
2. If no symptom matches, use the **Topic index** and match on subject.
3. Open a second file only when the entry you land on explicitly
   cross-references another file. Cross-references name their target file
   inline.
4. Severity callouts (`Severity: Critical` / `Severity: High`) mark failures
   that are silent - data loss or corruption with no error and a green
   execution. Surface those prominently, because the user usually does not
   know the failure is happening.

## Symptom lookup

| What the user says or sees | File |
| --- | --- |
| "Only the first item processed"; loop inside a loop; partially populated database; green run but missing data | `reference/loops-and-subworkflows.md` |
| Workflow halts on the first item waiting for an approval or callback | `reference/loops-and-subworkflows.md` |
| Hitting API rate limits partway through a run | `reference/loops-and-subworkflows.md` |
| Paginated API, unknown page count, cursor or `has_more` flag | `reference/loops-and-subworkflows.md` |
| Need "repeat N times"; infinite loop; instance crashed out of memory | `reference/loops-and-subworkflows.md` |
| `$('Node Name').json...` stopped resolving after a Code node; lost item pairing | `reference/data-flow-and-items.md` |
| Item disappears when a lookup finds no row; the FALSE branch never fires | `reference/data-flow-and-items.md` |
| Several items into one lookup: some silently dropped, or item count collapses to 1 | `reference/data-flow-and-items.md` |
| Node ran once when it should have run per item, or the reverse | `reference/data-flow-and-items.md` |
| `A 'json' property isn't an object [item 0]` | `reference/data-flow-and-items.md` |
| `An expression references this node, but the node is unexecuted` | `reference/data-flow-and-items.md` |
| Binary, image, or PDF will not pass downstream; `$json` reference comes back empty | `reference/binary-and-http.md` |
| `binary.data.data` is undefined, usually on larger files | `reference/binary-and-http.md` |
| HTTP node returns JSON on some responses and binary on others | `reference/binary-and-http.md` |
| Want model fallback on a vision call without wiring up multiple AI nodes | `reference/binary-and-http.md` |
| Large file crashed the instance | `reference/binary-and-http.md` |
| Merge node produces nothing; items missing after branches reconverge | `reference/merge-and-branching.md` |
| Merge node produces duplicates; a fallback ran when it should not have | `reference/merge-and-branching.md` |
| One node failing kills the whole workflow; need a fallback branch | `reference/merge-and-branching.md` |
| Everything after a lookup silently never runs | `reference/merge-and-branching.md` |
| Need `order`, `limit`, or `select` out of the Supabase node | `reference/supabase-postgres.md` |
| `EMAXCONNSESSION max clients reached in session mode - max clients are limited to pool_size: 15` | `reference/supabase-postgres.md` |
| Postgres works in testing, fails intermittently in production; `connection terminated unexpectedly` | `reference/supabase-postgres.md` |
| `invalid input syntax for type double precision: "false"`; values landing in the wrong columns | `reference/supabase-postgres.md` |
| Works in dev, fails in prod once real text data arrives | `reference/supabase-postgres.md` |
| `Service unavailable - try again later` from the Supabase node | `reference/supabase-postgres.md` |
| Need upsert, JOIN, CTE, or `RETURNING` against Supabase | `reference/supabase-postgres.md` |
| Which built-in node should I use instead of a Code node? | `reference/nodes-and-models.md` |
| No native n8n node exists for this service | `reference/nodes-and-models.md` |
| `Proto field is not repeating, cannot start list`; `Unknown name 'type' at 'path'`; Gemini schema errors | `reference/nodes-and-models.md` |

## Topic index

### `reference/loops-and-subworkflows.md`

Loop mechanics, sub-workflow architecture, recursion, throttling.

- Nested Loops Are Not Supported: Use Sub-Workflows - **Severity: Critical**
- Wait Node + Sub-Workflows: Parallel Processing for Approval Flows
- Loops + Wait Node: Handling Rate Limits
- Recursive Sub-Workflows: API Pagination Without Loops
- Fixed-Count Loops (Circuit Breaker Pattern)
- Unterminated Loops Will Crash Your Instance

### `reference/data-flow-and-items.md`

Item linking, item counts, Code node contracts, expression guards.

- Recovering Lost Data Links (including `pairedItem` and `itemMatching`)
- Always Output Data: Handle Empty Lookups Gracefully - **Severity: High** on the per-item caveat
- The "Execute Once" Setting
- Code Node Return Formats - **Severity: High**
- Referencing Unexecuted Nodes: The `$if` Guard
- JavaScript Expressions Are Powerful: Use Them

### `reference/binary-and-http.md`

Binary data handling and HTTP-based model calls.

- Binary Data Downstream
- HTTP Node: Always Return Binary Output
- OpenRouter for Vision: Multi-Model Fallback With One HTTP Call
- File Size Limits Will Crash Your Instance

### `reference/merge-and-branching.md`

Reconverging branches, error routing, empty-result guards.

- Merge Node Modes: Append vs Combine - **Severity: High**, includes a full importable reference workflow JSON
- Error Handling: Continue on Fail Options
- Preventing Silent Workflow Stops: Guard Against Empty Results

### `reference/supabase-postgres.md`

Supabase and Postgres node behaviour, connection setup, SQL migration.

- PostgREST Query Params in the Supabase Node's `filterString`
- Supabase Postgres Connections: Always Use the Transaction Pooler - **Severity: High**
- Postgres Node: `queryReplacement` Comma-Splitting Bug - **Severity: High**
- Supabase Node to Postgres Node Migration

### `reference/nodes-and-models.md`

Node selection and model-provider limits.

- Useful Internal Nodes
- When a Node Doesn't Exist or Doesn't Do What You Need
- Gemini Output Formatting Limitations
- Check for a Built-In Node Before Writing a Code Node

## Cross-file dependencies

These entries reference each other. Open the second file only when the user's
problem actually spans both.

- *Nested Loops Are Not Supported* and *Recursive Sub-Workflows* are the two
  halves of one decision (same file)
- *Always Output Data* (`data-flow-and-items.md`) and *Preventing Silent
  Workflow Stops* (`merge-and-branching.md`) are the two halves of the same
  fix: the setting keeps the item in the flow, the IF guard acts on it
- *OpenRouter for Vision* (`binary-and-http.md`) builds on *Binary Data
  Downstream* (same file) and on *Merge Node Modes*
  (`merge-and-branching.md`) for the fallback gate
- *Always Use the Transaction Pooler* is a prerequisite for *Supabase Node to
  Postgres Node Migration* (same file)
- *`queryReplacement` Comma-Splitting Bug* governs parameter binding in
  *Supabase Node to Postgres Node Migration* (same file)
- *Referencing Unexecuted Nodes: The `$if` Guard*
  (`data-flow-and-items.md`) is an alternative to a Merge node
  (`merge-and-branching.md`)

---

Source: n8n Pro-Tips by Edward Njogu - <https://edwardnjogu.com/n8n-pro-tips>
